<?php
session_start();
$_title = $_POST["title"];
$_content = $_POST["text"];

if ($_SESSION['loggedin'] == TRUE && $_title != "" && $_content != "") {
    $db = new mysqli('localhost', 'root', 'root', 'blogs');
    $sql = "INSERT INTO blogs (Title, Content) VALUES ('$_title', '$_content')"; 
    $result = $db->query($sql);
}

header('location: blog.html');
?>