document.getElementById('clear').addEventListener('click', function(e) {
    document.getElementById('clear-popup').style.display = "flex";
})

document.getElementById('cancel').addEventListener('click', function(e) {
    document.getElementById('clear-popup').style.display = "none";
})

document.getElementById('reset').addEventListener('click', function(e) {
    document.getElementById('clear-popup').style.display = "none";
})

document.getElementById('post').addEventListener('click', function(e) {
    if(document.getElementById('title').value === "" || document.getElementById('text').value === "") {
        e.preventDefault();
        document.getElementById('title').style.border = '1px solid red';
        document.getElementById('text').style.border = '1px solid red';
    }
})

document.getElementById('title').addEventListener('click', function(e) {
    document.getElementById('title').style.border = '1px solid #ccc';
})

document.getElementById('text').addEventListener('click', function(e) {
    document.getElementById('text').style.border = '1px solid #ccc';
})