<?php 

session_start();
$month = '00';//stores month 

if (isset($_POST['months'])) {//if month selected then value filtermonth is set
    $month = $_POST['months'];
    $_SESSION['month'] = $month;
}

header('location: blog.html');//reloads page
?>