<?php
session_start();

if (isset($_SESSION['loggedin']) == FALSE) {
    echo '<form action="validate.php" method="post">';
    echo '<input type="email" id="email" name="email" placeholder="Email" pattern="*@-.-" required>';
    echo '<input type="password" id="password" name="password" placeholder="Password" required>';
    echo '<input type="submit" value="Submit">';
    echo '</form>';
}

else {
    echo '<form action="logout.php" method="post">';
    echo '<input type="button" onclick="window.location=`addPost.html`;" value="Create Post">';
    echo '<br />';
    echo '<input type="submit" value="Logout">';
    echo '</form>';
}
?>