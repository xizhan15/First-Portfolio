document.getElementById('preview').addEventListener('click', function (e) {
    sessionStorage.setItem('post-title', document.getElementById('title').value);
    sessionStorage.setItem('post-text', document.getElementById('text').value);

    window.open('preview.html', '_self')
})