window.onload = function (e) { //when window load want that function to run
    if (sessionStorage.getItem("filterMonth") === null) {//if filterMonth doesnt exist and hasnt been set then slectitem goes to 00
        document.getElementById("months").value = "00";
    }

    else {
        document.getElementById("months").value = sessionStorage.getItem("filterMonth");//else if exists whatever filtermonth is getset as the new select item 

        sessionStorage.removeItem('filterMonth');//remove month storage and resets the month to 00 so when refresh shows all post, gpes back to 00 
    }
}

document.getElementById('months').addEventListener('change', function(e) {
    sessionStorage.setItem('filterMonth', document.getElementById('months').value); //item created called filterMonth.
    //filterMonth becomes new month value 
    //sessionStorage save data 
    //set items sets the variable to the value 
    //
})