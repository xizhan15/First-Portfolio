<?php
session_start();
$_SESSION['email'] = $_POST["email"];
$_SESSION['password'] = $_POST["password"];

$db = new mysqli('localhost', 'root', 'root', 'users');
$sql = "SELECT * FROM users"; 
$result = $db->query($sql);

while($row = $result->fetch_assoc()) {
    if ($_SESSION['email'] == $row["Email"] && $_SESSION['password'] == $row["Password"]) {  
        $_SESSION['loggedin'] = TRUE;
        header ("location: addPost.html");
    }
}

if (isset($_SESSION['loggedin']) == FALSE) {
    header ("location: login.html");
}
?>