<?php
session_start();

function showMonth($month) {
    $db = new mysqli('localhost', 'root', 'root', 'blogs');
    $sql = "SELECT * FROM blogs"; 
    $result = $db->query($sql); //intializes sql
    
    $array = $result->fetch_all(MYSQLI_ASSOC);//get all data from blogs

    usort($array, 'date_compare');
    $array = array_reverse($array);//lips to most recent into desceding order

    if ($result->num_rows > 0) {
        foreach($array as $row) {
            if ($month == '00') {//shpws all original posts when month isnt set
                echo '<li class="blog-card">';
                echo '<p class="time">'.$row["TimeDate"].'</p>';
                echo '<div class="blog-content">';
                echo '<p class="title">'.$row["Title"].'</p>';
                echo '<p class="text">'.$row["Content"].'</p>';
                echo '</div>';
                echo '</li>';
                echo '<hr/>';
            }

            if (getMonth($row['TimeDate']) == $month) {//ets the timedate to the month selsect
                echo '<li class="blog-card">';//prints put all the posts of the month slected
                echo '<p class="time">'.$row["TimeDate"].'</p>';
                echo '<div class="blog-content">';
                echo '<p class="title">'.$row["Title"].'</p>';
                echo '<p class="text">'.$row["Content"].'</p>';
                echo '</div>';
                echo '</li>';
                echo '<hr/>';
            }
        }
    }

    else {
        echo "No Blog Posts to display";
    }
}

function getMonth($date) {
    return substr($date, 5, 2);//deletes first 5 spaces before month ints and 2 spaces after, leaving only month int
}

//Sorting comaparision
function date_compare($element1, $element2) {
    $datetime1 = strtotime($element1['TimeDate']);
    $datetime2 = strtotime($element2['TimeDate']);
    return $datetime1 - $datetime2;
} 

if (isset($_SESSION['month'])) {//if a valie of month is stored or set
    showMonth($_SESSION['month']);//calls ths function and siaplays all the posts for that specfic month
    unset($_SESSION['month']);//delets month storage and resets the month to 00 so when refresh shows all posts 
}

else {
    showMonth('00');
}
?>