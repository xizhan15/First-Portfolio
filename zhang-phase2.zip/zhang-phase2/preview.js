window.onload = function (e) { //when window loads run function
    document.getElementById('preview-title').innerHTML = sessionStorage.getItem('post-title');//shows the unposted blog
    document.getElementById('preview-text').innerHTML = sessionStorage.getItem('post-text');


    document.getElementById('title').value = sessionStorage.getItem('post-title');//shows the input blog box
    document.getElementById('text').value = sessionStorage.getItem('post-text');
}